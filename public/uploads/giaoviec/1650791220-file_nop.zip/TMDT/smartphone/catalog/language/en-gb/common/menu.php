<?php
// Text
$_['text_all'] = 'Show All';